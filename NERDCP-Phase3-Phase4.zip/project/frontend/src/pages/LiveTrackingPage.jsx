import React, { useState, lazy, Suspense } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useTrackingSocket } from '../hooks/useWebSocket'
import { getIncidentById } from '../api/incidents'
import { LoadingSpinner } from '../components/Common/Feedback'
import { MapPin, Wifi, WifiOff, Trash2, Activity } from 'lucide-react'
import { format } from 'date-fns'

const TrackingMap = lazy(() => import('../components/Map/TrackingMap'))

const STATUS_COLORS = {
  open:         'var(--green)',
  connecting:   'var(--yellow)',
  closed:       'var(--text-muted)',
  error:        'var(--red)',
  disconnected: 'var(--text-muted)',
}

export default function LiveTrackingPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [inputId, setInputId] = useState(searchParams.get('incidentId') || '')
  const [activeId, setActiveId] = useState(searchParams.get('incidentId') || '')

  const { messages, status, lastUpdate, clear } = useTrackingSocket(activeId)

  const handleConnect = (e) => {
    e.preventDefault()
    if (!inputId.trim()) return
    setActiveId(inputId.trim())
    setSearchParams({ incidentId: inputId.trim() })
  }

  // Derive unique vehicle list from messages
  const vehicleMap = {}
  messages.forEach(m => {
    if (m.vehicleId) vehicleMap[m.vehicleId] = m
  })
  const vehicles = Object.values(vehicleMap)

  const wsColor = STATUS_COLORS[status] || 'var(--text-muted)'

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', height: 'calc(100vh - var(--header-h) - 3rem)', animation: 'fade-in-up 0.4s ease' }}>

      {/* Control bar */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: '1rem',
        flexWrap: 'wrap',
      }}>
        <form onSubmit={handleConnect} style={{ display: 'flex', gap: '0.5rem', flex: 1, minWidth: 280 }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <MapPin size={13} style={{
              position: 'absolute', left: '0.75rem', top: '50%',
              transform: 'translateY(-50%)', color: 'var(--text-muted)',
            }} />
            <input
              className="input"
              type="text"
              placeholder="Enter Incident ID to track…"
              value={inputId}
              onChange={e => setInputId(e.target.value)}
              style={{ paddingLeft: '2.25rem' }}
            />
          </div>
          <button type="submit" className="btn btn-primary" style={{ whiteSpace: 'nowrap' }}>
            Connect
          </button>
        </form>

        {/* WS status */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: '0.5rem',
          fontFamily: 'var(--font-mono)', fontSize: '0.68rem',
          color: wsColor,
        }}>
          {status === 'open' ? <Wifi size={14} /> : <WifiOff size={14} />}
          {status.toUpperCase()}
          {lastUpdate && (
            <span style={{ color: 'var(--text-muted)' }}>
              · {format(lastUpdate, 'HH:mm:ss')}
            </span>
          )}
        </div>

        {messages.length > 0 && (
          <button
            className="btn btn-ghost"
            onClick={clear}
            style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}
          >
            <Trash2 size={13} /> Clear
          </button>
        )}
      </div>

      {/* Main content: map + sidebar */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: '1rem', flex: 1, minHeight: 0 }}>

        {/* Map */}
        <div style={{ borderRadius: 'var(--radius-md)', overflow: 'hidden', position: 'relative' }}>
          {!activeId ? (
            <div style={{
              height: '100%', display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', gap: '0.75rem',
              background: 'var(--bg-card)', border: '1px solid var(--border)',
              borderRadius: 'var(--radius-md)', color: 'var(--text-muted)',
            }}>
              <MapPin size={36} strokeWidth={1} />
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.88rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                Enter Incident ID
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', textAlign: 'center', maxWidth: 240, lineHeight: 1.6 }}>
                Connect to a WebSocket stream to see live vehicle positions
              </div>
            </div>
          ) : (
            <Suspense fallback={<LoadingSpinner message="Loading tracking map…" />}>
              <TrackingMap messages={messages} />
            </Suspense>
          )}

          {/* Live overlay */}
          {status === 'open' && (
            <div style={{
              position: 'absolute', top: 10, left: 10,
              background: 'rgba(9,14,24,0.85)', backdropFilter: 'blur(4px)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-sm)', padding: '0.35rem 0.75rem',
              display: 'flex', alignItems: 'center', gap: '0.4rem',
              fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--green)',
              zIndex: 1000,
            }}>
              <span className="live-dot" />
              LIVE · {vehicles.length} vehicle{vehicles.length !== 1 ? 's' : ''}
            </div>
          )}
        </div>

        {/* Sidebar: vehicle list + event log */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', overflow: 'hidden' }}>

          {/* Active vehicles */}
          <div className="card" style={{ flexShrink: 0 }}>
            <div className="card-header">
              <Activity size={13} />
              Tracked Vehicles
            </div>
            {vehicles.length === 0 ? (
              <div style={{ padding: '1rem', textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)' }}>
                {activeId ? 'Waiting for data…' : 'Not connected'}
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                {vehicles.map((v, i) => (
                  <div key={v.vehicleId || i} style={{
                    padding: '0.5rem 0.6rem',
                    background: 'var(--bg-elevated)',
                    borderRadius: 'var(--radius-sm)',
                    borderLeft: '2px solid var(--blue)',
                  }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.75rem', fontWeight: 600 }}>
                      {v.name || v.vehicleId}
                    </div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-muted)', marginTop: '0.15rem' }}>
                      {v.lat?.toFixed(5)}, {v.lng?.toFixed(5)}
                    </div>
                    {v.speed != null && (
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--blue)' }}>
                        {v.speed} km/h · {v.type || 'vehicle'}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Event log */}
          <div className="card" style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <div className="card-header">
              <Activity size={13} />
              Event Stream
              <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-muted)' }}>
                {messages.length} events
              </span>
            </div>
            <div style={{ overflowY: 'auto', flex: 1 }}>
              {messages.length === 0 ? (
                <div style={{ padding: '1rem', textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
                  No events yet
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column-reverse' }}>
                  {[...messages].reverse().slice(0, 50).map((msg, i) => (
                    <div key={i} style={{
                      padding: '0.35rem 0.5rem',
                      borderBottom: '1px solid rgba(30,51,88,0.4)',
                      fontSize: '0.62rem',
                      fontFamily: 'var(--font-mono)',
                      color: 'var(--text-muted)',
                      lineHeight: 1.4,
                    }}>
                      <span style={{ color: 'var(--text-mono)' }}>
                        {msg.timestamp ? format(new Date(msg.timestamp), 'HH:mm:ss') : '—'}
                      </span>
                      {' '}{msg.vehicleId}{' '}
                      <span style={{ color: 'var(--text-secondary)' }}>
                        {msg.lat?.toFixed(4)},{msg.lng?.toFixed(4)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
