import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Radio, AlertTriangle, Eye, EyeOff } from 'lucide-react'

const DEMO_ROLES = [
  { email: 'admin@nerdcp.gh',    password: 'admin123',    role: 'Admin',    color: 'var(--red)' },
  { email: 'police@nerdcp.gh',   password: 'police123',   role: 'Police',   color: 'var(--police-blue)' },
  { email: 'fire@nerdcp.gh',     password: 'fire123',     role: 'Fire',     color: 'var(--fire-orange)' },
  { email: 'hospital@nerdcp.gh', password: 'hospital123', role: 'Hospital', color: 'var(--hospital-teal)' },
]

export default function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState({ email: '', password: '' })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const user = await login(form.email, form.password)
      navigate('/dashboard')
    } catch (err) {
      setError(err?.response?.data?.message || err.message || 'Login failed. Check your credentials.')
    } finally {
      setLoading(false)
    }
  }

  const fillDemo = (email, password) => setForm({ email, password })

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg-base)',
      display: 'flex',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Background grid lines */}
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.04,
        backgroundImage: `
          linear-gradient(var(--blue) 1px, transparent 1px),
          linear-gradient(90deg, var(--blue) 1px, transparent 1px)
        `,
        backgroundSize: '40px 40px',
        pointerEvents: 'none',
      }} />

      {/* Scan line animation */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        overflow: 'hidden', opacity: 0.03,
      }}>
        <div style={{
          width: '100%', height: '2px',
          background: 'linear-gradient(90deg, transparent, var(--blue), transparent)',
          animation: 'scan-line 6s linear infinite',
        }} />
      </div>

      {/* Left panel — branding */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        padding: '4rem',
        borderRight: '1px solid var(--border)',
        position: 'relative',
      }}>
        {/* Glow blob */}
        <div style={{
          position: 'absolute', width: 400, height: 400,
          background: 'radial-gradient(circle, rgba(255,45,74,0.08) 0%, transparent 70%)',
          top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          pointerEvents: 'none',
        }} />

        <div style={{ position: 'relative', animation: 'fade-in-up 0.6s ease forwards' }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '2rem',
          }}>
            <div style={{
              width: 48, height: 48, background: 'var(--red)', borderRadius: 8,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 0 20px var(--red-glow)',
            }}>
              <Radio size={24} color="#fff" />
            </div>
            <div>
              <div style={{
                fontFamily: 'var(--font-display)', fontWeight: 800,
                fontSize: '1.5rem', letterSpacing: '0.1em',
                color: 'var(--text-primary)',
              }}>NERDCP</div>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: '0.6rem',
                color: 'var(--text-muted)', letterSpacing: '0.1em',
              }}>SYSTEM v1.0</div>
            </div>
          </div>

          <h1 style={{
            fontFamily: 'var(--font-display)', fontSize: '2.5rem',
            fontWeight: 800, lineHeight: 1.1, marginBottom: '1rem',
            textTransform: 'uppercase', letterSpacing: '0.04em',
          }}>
            National<br />
            <span style={{ color: 'var(--red)' }}>Emergency</span><br />
            Response &amp;<br />
            Dispatch<br />
            Platform
          </h1>

          <p style={{
            color: 'var(--text-muted)', fontSize: '0.82rem',
            lineHeight: 1.7, maxWidth: 340,
          }}>
            Unified command and control for Hospital, Police, and Fire Service
            emergency response operations across Ghana.
          </p>

          <div style={{
            display: 'flex', gap: '0.6rem', marginTop: '1.75rem', flexWrap: 'wrap',
          }}>
            {['Hospital', 'Police', 'Fire Service'].map(svc => (
              <div key={svc} style={{
                padding: '0.3rem 0.75rem',
                border: '1px solid var(--border)',
                borderRadius: 2,
                fontFamily: 'var(--font-mono)',
                fontSize: '0.6rem',
                color: 'var(--text-muted)',
                letterSpacing: '0.08em',
              }}>{svc}</div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — login form */}
      <div style={{
        width: 480,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        padding: '3rem',
        animation: 'slide-in-left 0.5s ease forwards',
        animationDirection: 'reverse',
      }}>
        <div style={{
          fontFamily: 'var(--font-display)', fontSize: '1.1rem',
          fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase',
          color: 'var(--text-primary)', marginBottom: '0.25rem',
        }}>
          Operator Sign-In
        </div>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: '0.65rem',
          color: 'var(--text-muted)', marginBottom: '2rem',
        }}>
          Authorised personnel only
        </div>

        {/* Demo logins */}
        <div style={{ marginBottom: '1.75rem' }}>
          <div style={{
            fontFamily: 'var(--font-display)', fontSize: '0.6rem',
            fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase',
            color: 'var(--text-muted)', marginBottom: '0.5rem',
          }}>Quick Demo Login</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.4rem' }}>
            {DEMO_ROLES.map(d => (
              <button
                key={d.role}
                onClick={() => fillDemo(d.email, d.password)}
                style={{
                  background: 'var(--bg-elevated)',
                  border: `1px solid var(--border)`,
                  borderRadius: 'var(--radius-sm)',
                  padding: '0.4rem 0.6rem',
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'border-color 0.15s',
                }}
                onMouseOver={e => e.currentTarget.style.borderColor = d.color}
                onMouseOut={e => e.currentTarget.style.borderColor = 'var(--border)'}
              >
                <div style={{
                  fontFamily: 'var(--font-display)', fontSize: '0.72rem',
                  fontWeight: 600, color: d.color, letterSpacing: '0.06em',
                }}>{d.role}</div>
                <div style={{
                  fontFamily: 'var(--font-mono)', fontSize: '0.58rem',
                  color: 'var(--text-muted)', marginTop: '0.1rem',
                }}>{d.email}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div className="input-group">
            <label className="input-label">Email Address</label>
            <input
              className="input"
              type="email"
              placeholder="operator@nerdcp.gh"
              value={form.email}
              onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              required
              autoComplete="email"
            />
          </div>

          <div className="input-group">
            <label className="input-label">Password</label>
            <div style={{ position: 'relative' }}>
              <input
                className="input"
                type={showPw ? 'text' : 'password'}
                placeholder="••••••••"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                required
                autoComplete="current-password"
                style={{ paddingRight: '2.5rem' }}
              />
              <button
                type="button"
                onClick={() => setShowPw(s => !s)}
                style={{
                  position: 'absolute', right: '0.75rem', top: '50%',
                  transform: 'translateY(-50%)', background: 'none',
                  border: 'none', cursor: 'pointer', color: 'var(--text-muted)',
                  display: 'flex', alignItems: 'center',
                }}
              >
                {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          {error && (
            <div style={{
              background: 'rgba(255,45,74,0.1)',
              border: '1px solid rgba(255,45,74,0.4)',
              borderRadius: 'var(--radius-sm)',
              padding: '0.6rem 0.85rem',
              display: 'flex', alignItems: 'center', gap: '0.5rem',
            }}>
              <AlertTriangle size={14} color="var(--red)" />
              <span style={{ fontSize: '0.78rem', color: 'var(--red)' }}>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="btn btn-primary"
            disabled={loading}
            style={{ width: '100%', justifyContent: 'center', padding: '0.75rem', marginTop: '0.25rem', fontSize: '0.85rem' }}
          >
            {loading ? 'Authenticating…' : 'Access System'}
          </button>
        </form>

        <div style={{
          marginTop: '1.5rem', paddingTop: '1.25rem', borderTop: '1px solid var(--border)',
          fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-muted)',
          textAlign: 'center', lineHeight: 1.8,
        }}>
          CPEN 421 · University of Ghana · Emergency Operations Platform<br />
          Unauthorised access is prohibited
        </div>
      </div>
    </div>
  )
}
