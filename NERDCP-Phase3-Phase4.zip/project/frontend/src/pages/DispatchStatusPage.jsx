import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { getIncidents, updateIncidentStatus, dispatchIncident } from '../api/incidents'
import { LoadingSpinner, ErrorMessage, EmptyState } from '../components/Common/Feedback'
import StatusBadge from '../components/Common/StatusBadge'
import { Truck, RefreshCw, MapPin, ChevronRight, Filter, AlertCircle } from 'lucide-react'
import { formatDistanceToNow, format } from 'date-fns'

const STATUS_FILTERS = ['all', 'active', 'pending', 'dispatched', 'resolved']

const SEVERITY_ORDER = { critical: 0, high: 1, medium: 2, low: 3 }

export default function DispatchStatusPage() {
  const navigate = useNavigate()
  const [incidents, setIncidents] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [filter, setFilter] = useState('all')
  const [actionLoading, setActionLoading] = useState({})

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await getIncidents()
      const list = Array.isArray(data) ? data : data?.incidents || []
      // Sort by severity then date
      list.sort((a, b) => {
        const sA = SEVERITY_ORDER[a.severity?.toLowerCase()] ?? 99
        const sB = SEVERITY_ORDER[b.severity?.toLowerCase()] ?? 99
        if (sA !== sB) return sA - sB
        return new Date(b.createdAt) - new Date(a.createdAt)
      })
      setIncidents(list)
    } catch (e) { setError(e) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])
  useEffect(() => {
    const t = setInterval(load, 20_000)
    return () => clearInterval(t)
  }, [])

  const filtered = filter === 'all'
    ? incidents
    : incidents.filter(i => i.status?.toLowerCase() === filter)

  const handleDispatch = async (incidentId) => {
    setActionLoading(a => ({ ...a, [incidentId]: 'dispatch' }))
    try {
      await dispatchIncident(incidentId)
      await load()
    } catch (e) { alert(e?.response?.data?.message || 'Dispatch failed') }
    finally { setActionLoading(a => ({ ...a, [incidentId]: null })) }
  }

  const handleResolve = async (incidentId) => {
    setActionLoading(a => ({ ...a, [incidentId]: 'resolve' }))
    try {
      await updateIncidentStatus(incidentId, 'resolved')
      await load()
    } catch (e) { alert(e?.response?.data?.message || 'Update failed') }
    finally { setActionLoading(a => ({ ...a, [incidentId]: null })) }
  }

  const SEVERITY_COLORS = { critical: 'var(--red)', high: 'var(--orange)', medium: 'var(--yellow)', low: 'var(--green)' }

  if (loading && incidents.length === 0) return <LoadingSpinner message="Loading dispatch status…" />
  if (error) return <ErrorMessage error={error} onRetry={load} />

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', animation: 'fade-in-up 0.4s ease' }}>

      {/* Toolbar */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexWrap: 'wrap', gap: '0.75rem',
      }}>
        {/* Status filter tabs */}
        <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap' }}>
          {STATUS_FILTERS.map(s => {
            const count = s === 'all' ? incidents.length : incidents.filter(i => i.status?.toLowerCase() === s).length
            return (
              <button
                key={s}
                onClick={() => setFilter(s)}
                style={{
                  padding: '0.35rem 0.8rem',
                  background: filter === s ? 'var(--red)' : 'var(--bg-elevated)',
                  border: `1px solid ${filter === s ? 'var(--red)' : 'var(--border)'}`,
                  borderRadius: 'var(--radius-sm)',
                  color: filter === s ? '#fff' : 'var(--text-muted)',
                  fontFamily: 'var(--font-display)',
                  fontSize: '0.7rem', fontWeight: 600,
                  letterSpacing: '0.08em', textTransform: 'uppercase',
                  cursor: 'pointer', transition: 'all 0.15s',
                  display: 'flex', alignItems: 'center', gap: '0.35rem',
                }}
              >
                {s}
                <span style={{
                  background: filter === s ? 'rgba(255,255,255,0.2)' : 'var(--border)',
                  borderRadius: '10px', padding: '0 0.35rem',
                  fontFamily: 'var(--font-mono)', fontSize: '0.6rem',
                }}>{count}</span>
              </button>
            )
          })}
        </div>

        <button className="btn btn-secondary" onClick={load} style={{ fontSize: '0.72rem' }}>
          <RefreshCw size={13} style={{ animation: loading ? 'spin 1s linear infinite' : 'none' }} />
          Refresh
        </button>
      </div>

      {/* Incident cards */}
      {filtered.length === 0 ? (
        <EmptyState icon={Truck} title="No Incidents" description={`No ${filter} incidents to display`} />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {filtered.map(inc => {
            const id = inc.id || inc._id
            const sevColor = SEVERITY_COLORS[inc.severity?.toLowerCase()] || 'var(--text-muted)'
            const isActing = actionLoading[id]

            return (
              <div
                key={id}
                className="card"
                style={{
                  borderLeft: `4px solid ${sevColor}`,
                  transition: 'border-color 0.2s',
                }}
              >
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'auto 1fr auto',
                  gap: '1rem',
                  alignItems: 'start',
                }}>
                  {/* Severity indicator */}
                  <div style={{
                    width: 40, height: 40, borderRadius: 8,
                    background: `${sevColor}18`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0,
                  }}>
                    <AlertCircle size={20} color={sevColor} />
                  </div>

                  {/* Main info */}
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap', marginBottom: '0.3rem' }}>
                      <span style={{
                        fontFamily: 'var(--font-display)', fontSize: '0.88rem',
                        fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em',
                      }}>{inc.type || 'Unknown'}</span>
                      <StatusBadge status={inc.status} />
                      <span style={{
                        fontFamily: 'var(--font-mono)', fontSize: '0.62rem',
                        color: sevColor, textTransform: 'uppercase', letterSpacing: '0.1em',
                      }}>{inc.severity}</span>
                    </div>

                    <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                      <span style={{
                        display: 'flex', alignItems: 'center', gap: '0.3rem',
                        fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)',
                      }}>
                        <MapPin size={11} />
                        {inc.location?.address ||
                          (inc.location?.lat && `${Number(inc.location.lat).toFixed(4)}, ${Number(inc.location.lng).toFixed(4)}`) ||
                          'Location not set'}
                      </span>

                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
                        ID: #{String(id).slice(-8).toUpperCase()}
                      </span>

                      {inc.createdAt && (
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
                          {formatDistanceToNow(new Date(inc.createdAt), { addSuffix: true })}
                        </span>
                      )}
                    </div>

                    {inc.description && (
                      <p style={{
                        marginTop: '0.4rem', fontSize: '0.78rem', color: 'var(--text-secondary)',
                        lineHeight: 1.5,
                      }}>
                        {inc.description.slice(0, 180)}{inc.description.length > 180 ? '…' : ''}
                      </p>
                    )}

                    {/* Assigned responders */}
                    {inc.responders?.length > 0 && (
                      <div style={{
                        marginTop: '0.5rem', display: 'flex', gap: '0.4rem', flexWrap: 'wrap',
                      }}>
                        {inc.responders.map((r, i) => (
                          <span key={i} style={{
                            background: 'var(--blue-dim)', border: '1px solid var(--blue)',
                            borderRadius: 2, padding: '0.15rem 0.5rem',
                            fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--blue)',
                          }}>
                            {r.name || `Unit-${i + 1}`}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', minWidth: 110 }}>
                    <button
                      className="btn btn-ghost"
                      onClick={() => navigate(`/tracking?incidentId=${id}`)}
                      style={{ fontSize: '0.7rem', justifyContent: 'space-between' }}
                    >
                      Track <ChevronRight size={12} />
                    </button>

                    {inc.status === 'active' && (
                      <button
                        className="btn btn-primary"
                        disabled={!!isActing}
                        onClick={() => handleDispatch(id)}
                        style={{ fontSize: '0.7rem', justifyContent: 'center' }}
                      >
                        {isActing === 'dispatch' ? '…' : 'Dispatch'}
                      </button>
                    )}

                    {inc.status === 'dispatched' && (
                      <button
                        className="btn btn-secondary"
                        disabled={!!isActing}
                        onClick={() => handleResolve(id)}
                        style={{ fontSize: '0.7rem', justifyContent: 'center', borderColor: 'var(--green)', color: 'var(--green)' }}
                      >
                        {isActing === 'resolve' ? '…' : 'Resolve'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
