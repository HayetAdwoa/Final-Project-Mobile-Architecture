// ── dispatch.js ──────────────────────────────────────────────
import axios from 'axios'

const DISPATCH_BASE  = import.meta.env.VITE_DISPATCH_URL  || 'http://localhost:4003'
const ANALYTICS_BASE = import.meta.env.VITE_ANALYTICS_URL || 'http://localhost:4004'
const RESPONDER_BASE = import.meta.env.VITE_RESPONDER_URL || 'http://localhost:4005'

function authHeader() {
  const token = localStorage.getItem('nerdcp_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

// ── Dispatch ─────────────────────────────────────────────────
export async function getVehicleLocation(vehicleId) {
  const res = await axios.get(`${DISPATCH_BASE}/dispatch/location/${vehicleId}`, {
    headers: authHeader()
  })
  return res.data
}

export async function updateVehicleLocation(vehicleId, lat, lng) {
  const res = await axios.post(`${DISPATCH_BASE}/dispatch/location`, {
    vehicleId, lat, lng
  }, { headers: authHeader() })
  return res.data
}

export async function getActiveDispatches() {
  const res = await axios.get(`${DISPATCH_BASE}/dispatch/active`, {
    headers: authHeader()
  })
  return res.data
}

// ── Analytics ────────────────────────────────────────────────
export async function getAnalyticsSummary() {
  const res = await axios.get(`${ANALYTICS_BASE}/analytics/summary`, {
    headers: authHeader()
  })
  return res.data
}

export async function getIncidentsByType() {
  const res = await axios.get(`${ANALYTICS_BASE}/analytics/incidents-by-type`, {
    headers: authHeader()
  })
  return res.data
}

export async function getResponseTimes() {
  const res = await axios.get(`${ANALYTICS_BASE}/analytics/response-times`, {
    headers: authHeader()
  })
  return res.data
}

export async function getResourceUtilization() {
  const res = await axios.get(`${ANALYTICS_BASE}/analytics/resource-utilization`, {
    headers: authHeader()
  })
  return res.data
}

// ── Responders ───────────────────────────────────────────────
export async function getNearestResponders(lat, lng, type) {
  const res = await axios.get(`${RESPONDER_BASE}/responders/nearest`, {
    headers: authHeader(),
    params: { lat, lng, type }
  })
  return res.data
}

export async function getAllResponders() {
  const res = await axios.get(`${RESPONDER_BASE}/responders`, {
    headers: authHeader()
  })
  return res.data
}

export async function getResponderById(id) {
  const res = await axios.get(`${RESPONDER_BASE}/responders/${id}`, {
    headers: authHeader()
  })
  return res.data
}
