import axios from 'axios'

const BASE = import.meta.env.VITE_AUTH_URL || 'http://localhost:4001'

export async function loginUser(email, password) {
  const res = await axios.post(`${BASE}/auth/login`, { email, password })
  return res.data
}

export async function registerUser(payload) {
  const res = await axios.post(`${BASE}/auth/register`, payload)
  return res.data
}
