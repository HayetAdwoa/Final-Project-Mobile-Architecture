import axios from 'axios'

const BASE = import.meta.env.VITE_INCIDENT_URL || 'http://localhost:4002'

function authHeader() {
  const token = localStorage.getItem('nerdcp_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

export async function createIncident(payload) {
  const res = await axios.post(`${BASE}/incidents`, payload, {
    headers: authHeader()
  })
  return res.data
}

export async function getIncidents(params = {}) {
  const res = await axios.get(`${BASE}/incidents`, {
    headers: authHeader(),
    params
  })
  return res.data
}

export async function getIncidentById(id) {
  const res = await axios.get(`${BASE}/incidents/${id}`, {
    headers: authHeader()
  })
  return res.data
}

export async function updateIncidentStatus(id, status) {
  const res = await axios.patch(`${BASE}/incidents/${id}/status`, { status }, {
    headers: authHeader()
  })
  return res.data
}

export async function dispatchIncident(id) {
  const res = await axios.post(`${BASE}/incidents/${id}/dispatch`, {}, {
    headers: authHeader()
  })
  return res.data
}
