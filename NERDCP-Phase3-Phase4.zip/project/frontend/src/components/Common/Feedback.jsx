import React from 'react'

export function LoadingSpinner({ message = 'Loading…', size = 'md' }) {
  const dim = size === 'sm' ? 20 : size === 'lg' ? 48 : 32

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '0.75rem',
      padding: '2rem',
      color: 'var(--text-muted)',
    }}>
      <svg width={dim} height={dim} viewBox="0 0 24 24" fill="none"
        style={{ animation: 'spin 0.8s linear infinite' }}>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        <circle cx="12" cy="12" r="10" stroke="var(--border)" strokeWidth="2" />
        <path d="M12 2a10 10 0 0 1 10 10" stroke="var(--red)" strokeWidth="2"
          strokeLinecap="round" />
      </svg>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', letterSpacing: '0.06em' }}>
        {message}
      </span>
    </div>
  )
}

export function ErrorMessage({ error, onRetry }) {
  return (
    <div style={{
      background: 'rgba(255,45,74,0.08)',
      border: '1px solid rgba(255,45,74,0.3)',
      borderRadius: 'var(--radius-sm)',
      padding: '1rem 1.25rem',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '1rem',
    }}>
      <div>
        <div style={{
          fontFamily: 'var(--font-display)',
          fontSize: '0.72rem',
          fontWeight: 600,
          letterSpacing: '0.1em',
          color: 'var(--red)',
          textTransform: 'uppercase',
          marginBottom: '0.2rem',
        }}>Error</div>
        <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
          {error?.message || String(error) || 'An unexpected error occurred.'}
        </div>
      </div>
      {onRetry && (
        <button className="btn btn-secondary" onClick={onRetry}
          style={{ whiteSpace: 'nowrap', fontSize: '0.72rem' }}>
          Retry
        </button>
      )}
    </div>
  )
}

export function EmptyState({ icon: Icon, title, description }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', padding: '3rem 2rem', gap: '0.75rem',
      color: 'var(--text-muted)',
    }}>
      {Icon && <Icon size={36} strokeWidth={1} />}
      <div style={{
        fontFamily: 'var(--font-display)', fontSize: '0.9rem',
        fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase',
        color: 'var(--text-secondary)',
      }}>{title}</div>
      {description && (
        <div style={{ fontSize: '0.78rem', textAlign: 'center', maxWidth: 280 }}>
          {description}
        </div>
      )}
    </div>
  )
}
