import React from 'react'

const STATUS_MAP = {
  active:     { label: 'Active',     cls: 'badge-red'    },
  pending:    { label: 'Pending',    cls: 'badge-yellow'  },
  dispatched: { label: 'Dispatched', cls: 'badge-blue'   },
  resolved:   { label: 'Resolved',  cls: 'badge-green'   },
  closed:     { label: 'Closed',    cls: 'badge-green'   },
  online:     { label: 'Online',    cls: 'badge-green'   },
  offline:    { label: 'Offline',   cls: 'badge-yellow'  },
  engaged:    { label: 'Engaged',   cls: 'badge-red'     },
}

export default function StatusBadge({ status }) {
  const s = STATUS_MAP[status?.toLowerCase()] || { label: status, cls: 'badge-yellow' }
  return <span className={`badge ${s.cls}`}>{s.label}</span>
}
