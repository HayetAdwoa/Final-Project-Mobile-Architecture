import React, { useState, useEffect, useRef } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, ZoomControl } from 'react-leaflet'
import L from 'leaflet'

// Fix default leaflet icon paths
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

// Custom red emergency marker
const emergencyIcon = L.divIcon({
  html: `<div style="
    width:24px; height:24px;
    background: var(--red, #ff2d4a);
    border: 3px solid #fff;
    border-radius: 50% 50% 50% 0;
    transform: rotate(-45deg);
    box-shadow: 0 0 0 4px rgba(255,45,74,0.35), 0 4px 8px rgba(0,0,0,0.4);
  "></div>`,
  className: '',
  iconSize: [24, 24],
  iconAnchor: [12, 24],
})

// Custom blue responder marker
const responderIcon = L.divIcon({
  html: `<div style="
    width:20px; height:20px;
    background: #2979ff;
    border: 2px solid #fff;
    border-radius: 50%;
    box-shadow: 0 0 0 3px rgba(41,121,255,0.4), 0 3px 6px rgba(0,0,0,0.4);
  "></div>`,
  className: '',
  iconSize: [20, 20],
  iconAnchor: [10, 10],
})

function ClickHandler({ onLocationSelect }) {
  useMapEvents({
    click(e) {
      onLocationSelect({ lat: e.latlng.lat, lng: e.latlng.lng })
    }
  })
  return null
}

export default function IncidentMap({
  onLocationSelect,
  selectedLocation,
  responders = [],
  height = '400px',
  readOnly = false,
}) {
  // Default center: Ghana (Accra)
  const defaultCenter = [5.6037, -0.1870]
  const center = selectedLocation
    ? [selectedLocation.lat, selectedLocation.lng]
    : defaultCenter

  return (
    <div style={{
      height,
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      border: '1px solid var(--border)',
      position: 'relative',
    }}>
      {!readOnly && (
        <div style={{
          position: 'absolute', top: 10, left: '50%',
          transform: 'translateX(-50%)',
          background: 'rgba(9,14,24,0.85)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius-sm)',
          padding: '0.3rem 0.75rem',
          fontFamily: 'var(--font-mono)',
          fontSize: '0.65rem',
          color: 'var(--text-secondary)',
          zIndex: 1000,
          pointerEvents: 'none',
          letterSpacing: '0.06em',
        }}>
          Click map to set incident location
        </div>
      )}

      <MapContainer
        center={center}
        zoom={12}
        style={{ height: '100%', width: '100%' }}
        zoomControl={false}
      >
        <ZoomControl position="bottomright" />
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
          maxZoom={19}
        />

        {!readOnly && onLocationSelect && (
          <ClickHandler onLocationSelect={onLocationSelect} />
        )}

        {selectedLocation && (
          <Marker
            position={[selectedLocation.lat, selectedLocation.lng]}
            icon={emergencyIcon}
          >
            <Popup>
              <strong style={{ color: 'var(--red)' }}>Incident Location</strong><br />
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem' }}>
                {selectedLocation.lat.toFixed(5)}, {selectedLocation.lng.toFixed(5)}
              </span>
            </Popup>
          </Marker>
        )}

        {responders.map((r, i) => (
          <Marker
            key={r.id || i}
            position={[r.lat || r.latitude, r.lng || r.longitude]}
            icon={responderIcon}
          >
            <Popup>
              <strong>{r.name || `Responder ${i + 1}`}</strong><br />
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem' }}>
                {r.type || 'Unit'} — {r.status || 'Available'}
              </span>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}
